import asyncio
import pygame
from src.menu import Menu
from src.jogo import Jogo
from src.creditos import Creditos
from src.dados import Data, dados_padrao
from src.configuracao import *


async def main():
    pygame.init()
    tela = pygame.display.set_mode((LARGURA_TELA, ALTURA_TELA))
    pygame.display.set_caption("Perdido no Algoritmo")
    relogio = pygame.time.Clock()

    executando = True
    while executando:
        menu = Menu(tela, relogio)
        acao = await menu.rodar()

        if acao == "sair":
            executando = False

        elif acao == "novo_jogo":
            Data.salvar_dados(dados_padrao)
            meu_jogo = Jogo()
            resultado = await meu_jogo.rodar()
            if resultado == "sair":
                executando = False

        elif acao == "continuar":
            meu_jogo = Jogo()
            resultado = await meu_jogo.rodar()
            if resultado == "sair":
                executando = False

        elif acao == "creditos":
            creditos = Creditos(tela, relogio)
            resultado = await creditos.rodar()
            if resultado == "sair":
                executando = False

    pygame.quit()


asyncio.run(main())
